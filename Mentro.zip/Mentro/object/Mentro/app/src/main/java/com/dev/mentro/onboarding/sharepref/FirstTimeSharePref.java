package com.dev.mentro.onboarding.sharepref;

import android.content.Context;
import android.content.SharedPreferences;

public class FirstTimeSharePref {
    Context context;
    SharedPreferences preferences;

    public FirstTimeSharePref(Context context) {
        this.context = context;
        preferences = context.getSharedPreferences("first_time_user", 0);
    }

    public void saveFirstTime(int firstTime) {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt("is_first_time", 1);
        editor.apply();
    }

    public int getFirstTimeUser() {
        int firstTime = preferences.getInt("is_first_time", 0);
        return firstTime;
    }
}
