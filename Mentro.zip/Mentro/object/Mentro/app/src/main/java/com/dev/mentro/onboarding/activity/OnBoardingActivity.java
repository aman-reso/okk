package com.dev.mentro.onboarding.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import com.dev.mentro.R;
import com.dev.mentro.onboarding.adapter.OnBoardingAdapter;
import com.dev.mentro.onboarding.model.OnBoardModelItem;
import com.dev.mentro.onboarding.sharepref.FirstTimeSharePref;
import com.ornach.nobobutton.NoboButton;
import com.tbuonomo.viewpagerdotsindicator.DotsIndicator;
import com.tbuonomo.viewpagerdotsindicator.WormDotsIndicator;

import java.util.ArrayList;


public class OnBoardingActivity extends AppCompatActivity implements View.OnClickListener, ViewPager.OnPageChangeListener {
    private NoboButton nextButton, getStartedBtn;
    protected TextView skipTV;
    protected DotsIndicator viewPagerIndicator;
    protected ViewPager viewPager;
    protected OnBoardingAdapter onBoardingAdapter;
    protected ArrayList<OnBoardModelItem> modelItems;
    private FirstTimeSharePref sharePref;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.onboarding_activity);
        initializeView();

        //for first time user pref initialization
        sharePref = new FirstTimeSharePref(this);
        modelItems = new ArrayList<>();
        modelItems.add(new OnBoardModelItem(R.drawable.ic_launcher_background, "this is the first page",
                "first page description"));
        modelItems.add(new OnBoardModelItem(R.drawable.ic_launcher_background, "this is the second page",
                "second page description"));
        modelItems.add(new OnBoardModelItem(R.drawable.arrow_next, "this is the third page",
                "third page description"));
        onBoardingAdapter = new OnBoardingAdapter(this, modelItems);
        viewPager.setAdapter(onBoardingAdapter);
        viewPagerIndicator.setViewPager(viewPager);


        skipTV.setOnClickListener(this);
        nextButton.setOnClickListener(this);
        getStartedBtn.setOnClickListener(this);
        viewPager.setOnPageChangeListener(this);
    }

    private void initializeView() {
        skipTV = findViewById(R.id.onboarding_skip_btn);
        nextButton = findViewById(R.id.onboarding_next_btn);
        viewPager = findViewById(R.id.onboarding_viewpager);
        viewPagerIndicator = findViewById(R.id.onboard_viewIndicator);
        getStartedBtn = findViewById(R.id.get_started_btn);
    }

    @Override
    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.onboarding_skip_btn) {
            SaveFirstTimeData(1);
            callNextActivity();
        }
        if (id == R.id.onboarding_next_btn) {
            System.out.println(viewPager.getCurrentItem());
            if (viewPager.getCurrentItem() < 3) {
                viewPager.setCurrentItem(viewPager.getCurrentItem() + 1, true);
            }

        }
        if (id == R.id.get_started_btn) {
            SaveFirstTimeData(1);
            callNextActivity();
        }
    }

    private void callNextActivity() {
        Intent i = new Intent(OnBoardingActivity.this, HomeActivity.class);
        startActivity(i);
        finish();
    }

    private void SaveFirstTimeData(int i) {
        sharePref.saveFirstTime(i);
    }

    private int getFirstTimeData() {
        return sharePref.getFirstTimeUser();
    }
    //for view pager page scrolled

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {
        if (position == 2) {
            nextButton.setVisibility(View.GONE);
            skipTV.setVisibility(View.GONE);
            getStartedBtn.setVisibility(View.VISIBLE);
        } else {
            nextButton.setVisibility(View.VISIBLE);
            skipTV.setVisibility(View.VISIBLE);
            getStartedBtn.setVisibility(View.GONE);
        }
    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }
}