package com.dev.mentro.onboarding.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.dev.mentro.R;
import com.dev.mentro.onboarding.model.OnBoardModelItem;

import java.util.ArrayList;

public class OnBoardingAdapter extends PagerAdapter {
    Context context;
    ArrayList<OnBoardModelItem> list;

    public OnBoardingAdapter(Context context, ArrayList<OnBoardModelItem> list) {
        this.context = context;
        this.list = list;
    }

    @Override
    public int getCount() {
        if (!list.isEmpty()) {
            return list.size();

        } else {
            return 0;
        }
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == object;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {

        View itemView = LayoutInflater.from(context).inflate(R.layout.onboard_item, container, false);

        OnBoardModelItem item = list.get(position);

        ImageView imageView = itemView.findViewById(R.id.onboard_iv);
        imageView.setImageResource(item.getImageID());

        TextView tv_title = itemView.findViewById(R.id.onboard_titleTV);
        tv_title.setText(item.getTitle());

        TextView tv_content = itemView.findViewById(R.id.onboard_desTv);
        tv_content.setText(item.getDescription());

        container.addView(itemView);

        return itemView;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((ConstraintLayout) object);
    }
}
